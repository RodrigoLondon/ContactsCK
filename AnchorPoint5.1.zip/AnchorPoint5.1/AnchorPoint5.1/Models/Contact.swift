//
//  Contact.swift
//  AnchorPoint5.1
//
//  Created by Lewis Jones on 05/04/2019.
//  Copyright © 2019 Rodrigo. All rights reserved.
//

import Foundation
import CloudKit



class Contact {
    
    //MARK: - Properties
    var name: String
    var phoneNumber: String
    var email: String
    let ckRecordID:CKRecord.ID
    
    //Initializer
    init(name: String, phoneNumber: String, email: String, ckRecordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString)){
        self.name = name
        self.phoneNumber = phoneNumber
        self.email = email
        self.ckRecordID = ckRecordID
    }
    
    //Failable initializer
    convenience init?(ckRecord: CKRecord){
        guard let name = ckRecord[Constants.NameKey] as? String,
            let phoneNumber = ckRecord[Constants.PhoneNumberKey] as? String,
            let email = ckRecord[Constants.EmailKey] as? String else {return nil}
        
        self.init(name: name, phoneNumber: phoneNumber, email: email, ckRecordID: ckRecord.recordID)
    }
}

//Extension
extension CKRecord{
    convenience init(contact: Contact){
        self.init(recordType: Constants.ContactRecordType, recordID: contact.ckRecordID)
        self.setValue(contact.name, forKey: Constants.NameKey)
        self.setValue(contact.phoneNumber, forKey: Constants.PhoneNumberKey)
        self.setValue(contact.email, forKey: Constants.EmailKey)
    }
}

//Constants
struct Constants{
    static let ContactRecordType = "Contact"
    static let NameKey = "Name"
    static let PhoneNumberKey = "PhoneNumber"
    static let EmailKey = "Email"
}
