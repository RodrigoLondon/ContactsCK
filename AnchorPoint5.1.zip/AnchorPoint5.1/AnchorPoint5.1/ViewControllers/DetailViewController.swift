//
//  DetailViewController.swift
//  AnchorPoint5.1
//
//  Created by Lewis Jones on 05/04/2019.
//  Copyright © 2019 Rodrigo. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    //Source of truth
        var contact: Contact?{
            didSet{
                loadViewIfNeeded()
                updateViews()
            }
        }
    
        //Outlets
        @IBOutlet weak var nameTextField: UITextField!
        @IBOutlet weak var phoneNumberTextField: UITextField!
        @IBOutlet weak var emailTextField: UITextField!
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
        }
    
    //Update
        func updateViews(){
            guard let contact = contact else {return}
            nameTextField.text = contact.name
            phoneNumberTextField.text = contact.phoneNumber
            emailTextField.text = contact.email
        }
    
    //Save
        @IBAction func saveButtonTapped(_ sender: Any) {
            guard let nameText = nameTextField.text else {return}
            if let contact = contact{
                ContactController.shared.updateContact(contact: contact, name: nameText, phoneNumber: phoneNumberTextField.text ?? "", email: emailTextField.text ?? "") { (success) in
                    if success{
                        print("Success Updating")
                        DispatchQueue.main.async {
                            self.navigationController?.popViewController(animated: true)
                        }
                    }else{
                        print("Failed to Update")
                    }
                }
            }else{
                ContactController.shared.createContact(name: nameText, phoneNumber: phoneNumberTextField.text ?? "", email: emailTextField.text ?? "") { (_) in
                    
                }
                self.navigationController?.popViewController(animated: true)
            }
            
        }
    }


